﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Компилятор
{
    public class ProcedureInfo
    {
        public List<string> ParameterTypes 
        { 
            get; 
            set; 
        }
        public ProcedureInfo()
        {
            ParameterTypes = new List<string>();
        }
    }
}
