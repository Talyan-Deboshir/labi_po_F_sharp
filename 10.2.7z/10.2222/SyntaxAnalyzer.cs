using System;
using System.Collections.Generic;

namespace Компилятор
{
    class SyntaxAnalyzer
    {
        private LexicalAnalyzer lexer;
        private byte currentToken;
        private Dictionary<string, string> declaredVariables;
        private Dictionary<string, ProcedureInfo> declaredProcedures;
        private bool hasErrors;

        

        public SyntaxAnalyzer()
        {
            lexer = new LexicalAnalyzer();
            declaredVariables = new Dictionary<string, string>();
            declaredProcedures = new Dictionary<string, ProcedureInfo>();
            hasErrors = false;
        }

        public void AnalyzeProgram()
        {
            NextToken();
            ParseProgram();
        }

        private void NextToken()
        {
            currentToken = lexer.NextSym();
        }

        private void AddSyntaxError(int errorCode, string description)
        {
            InputOutput.AddError(errorCode, description);
            hasErrors = true;
        }

        private void ParseProgram()
        {
            if (currentToken == LexicalAnalyzer.programsy)
            {
                NextToken();
                if (currentToken == LexicalAnalyzer.ident)
                {
                    NextToken();
                    if (currentToken != LexicalAnalyzer.semicolon)
                        AddSyntaxError(101, "Ожидался ';' после имени программы");
                    else
                        NextToken();
                }
            }

            if (currentToken == LexicalAnalyzer.varsy)
            {
                ParseVariableDeclarations();
            }

            while (currentToken == LexicalAnalyzer.procedurensy)
            {
                ParseProcedureDeclaration();
            }

            ParseCompoundStatement();

            if (currentToken != LexicalAnalyzer.point)
            {
                AddSyntaxError(103, "Ожидалась '.' в конце программы");
            }
        }

        private void ParseVariableDeclarations()
        {
            NextToken();

            while (currentToken == LexicalAnalyzer.ident)
            {
                string varName = GetCurrentIdentifier();
                NextToken();

                if (declaredVariables.ContainsKey(varName))
                {
                    AddSyntaxError(104, $"Повторное объявление переменной '{varName}'");
                }

                if (currentToken == LexicalAnalyzer.equal)
                {
                    AddSyntaxError(105, "Использован '=' вместо ':' в объявлении переменной");
                    NextToken();
                }
                else if (currentToken == LexicalAnalyzer.colon)
                {
                    NextToken();
                }

                string varType = ParseType();

                if (!declaredVariables.ContainsKey(varName))
                {
                    declaredVariables[varName] = varType;
                }

                if (currentToken != LexicalAnalyzer.semicolon)
                    AddSyntaxError(107, "Ожидался ';' после объявления переменной");
                else
                    NextToken();
            }
        }

        private string ParseType()
        {
            if (currentToken == LexicalAnalyzer.integersy)
            {
                NextToken();
                return "integer";
            }
            else if (currentToken == LexicalAnalyzer.realsy)
            {
                NextToken();
                return "real";
            }
            else if (currentToken == LexicalAnalyzer.charsy)
            {
                NextToken();
                return "char";
            }
            else if (currentToken == LexicalAnalyzer.booleansy)
            {
                NextToken();
                return "boolean";
            }
            else if (currentToken == LexicalAnalyzer.arraysy)
            {
                return ParseArrayType();
            }
            return null;
        }

        private string ParseArrayType()
        {
            NextToken();
            
            if (currentToken != LexicalAnalyzer.lbracket)
            {
                AddSyntaxError(108, "Ожидался '[' после 'array'");
                return "array of unknown";
            }
            NextToken();
            
            if (currentToken == LexicalAnalyzer.intc) 
            {
                NextToken();
            }
            else
            {
                while (currentToken != LexicalAnalyzer.twopoints && 
                       currentToken != LexicalAnalyzer.rbracket && 
                       currentToken != 0)
                {
                    NextToken();
                }
            }
            
            if (currentToken == LexicalAnalyzer.twopoints)
            {
                NextToken();
            }
            else
            {
                while (currentToken != LexicalAnalyzer.intc && 
                       currentToken != LexicalAnalyzer.rbracket && 
                       currentToken != 0)
                {
                    NextToken();
                }
            }
            
            if (currentToken == LexicalAnalyzer.intc) 
            {
                NextToken();
            }
            
            if (currentToken == LexicalAnalyzer.rbracket)
            {
                NextToken();
            }
            else
            {
                AddSyntaxError(109, "Ожидался ']' после индексов массива");
                while (currentToken != LexicalAnalyzer.ofsy && 
                       currentToken != LexicalAnalyzer.integersy &&
                       currentToken != LexicalAnalyzer.realsy &&
                       currentToken != LexicalAnalyzer.charsy &&
                       currentToken != LexicalAnalyzer.booleansy &&
                       currentToken != LexicalAnalyzer.semicolon &&
                       currentToken != 0)
                {
                    NextToken();
                }
            }
            
            if (currentToken == LexicalAnalyzer.ofsy)
            {
                NextToken();
                string elementType = ParseType();
                if (elementType == null)
                {
                    AddSyntaxError(111, "Отсутствует тип элементов массива");
                    return "array of unknown";
                }
                return $"array of {elementType}";
            }
            else if (currentToken == LexicalAnalyzer.integersy || 
                     currentToken == LexicalAnalyzer.realsy || 
                     currentToken == LexicalAnalyzer.charsy ||
                     currentToken == LexicalAnalyzer.booleansy)
            {
                AddSyntaxError(112, "Отсутствует 'of' в объявлении массива");
                string elementType = ParseType();
                return elementType != null ? $"array of {elementType}" : "array of unknown";
            }
            else
            {
                AddSyntaxError(111, "Отсутствует тип элементов массива");
                return "array of unknown";
            }
        }

        private void ParseProcedureDeclaration()
        {
            NextToken();
            
            if (currentToken == LexicalAnalyzer.ident)
            {
                string procName = GetCurrentIdentifier();
                NextToken();

                ProcedureInfo procInfo = new ProcedureInfo();

                if (currentToken == LexicalAnalyzer.leftpar)
                {
                    NextToken();
                    ParseParameterList(procInfo);
                    if (currentToken != LexicalAnalyzer.rightpar)
                        AddSyntaxError(114, "Ожидался ')' после списка параметров");
                    else
                        NextToken();
                }
                else if (currentToken != LexicalAnalyzer.semicolon)
                {
                    AddSyntaxError(113, "Ожидался '(' для списка параметров или ';' после имени процедуры");
                }

                if (currentToken != LexicalAnalyzer.semicolon)
                    AddSyntaxError(115, "Ожидался ';' после заголовка процедуры");
                else
                    NextToken();

                declaredProcedures[procName] = procInfo;
                ParseCompoundStatement();

                if (currentToken != LexicalAnalyzer.semicolon)
                    AddSyntaxError(116, "Ожидался ';' после тела процедуры");
                else
                    NextToken();
            }
        }

        private void ParseParameterList(ProcedureInfo procInfo)
        {
            while (currentToken == LexicalAnalyzer.ident)
            {
                NextToken();
                
                if (currentToken == LexicalAnalyzer.colon)
                {
                    NextToken();
                }
                else if (currentToken == LexicalAnalyzer.integersy || 
                         currentToken == LexicalAnalyzer.realsy || 
                         currentToken == LexicalAnalyzer.charsy ||
                         currentToken == LexicalAnalyzer.booleansy)
                {
                    AddSyntaxError(118, "Отсутствует ':' перед типом параметра");
                }
                else
                {
                    AddSyntaxError(118, "Отсутствует ':' перед типом параметра");
                }
                
                string paramType = ParseType();
                if (paramType != null)
                {
                    procInfo.ParameterTypes.Add(paramType);
                }

                if (currentToken == LexicalAnalyzer.semicolon)
                {
                    NextToken();
                }
                else if (currentToken != LexicalAnalyzer.rightpar)
                {
                    break;
                }
            }
        }

        private void ParseCompoundStatement()
        {
            if (currentToken != LexicalAnalyzer.beginsy)
                AddSyntaxError(121, "Ожидался 'begin'");
            else
                NextToken();

            while (currentToken != LexicalAnalyzer.endsy && currentToken != 0)
            {
                if (currentToken == LexicalAnalyzer.beginsy)
                {
                    AddSyntaxError(122, "Лишний 'begin'");
                    NextToken();
                    continue;
                }
                
                ParseStatement();
                
                if (currentToken == LexicalAnalyzer.semicolon)
                {
                    NextToken();
                }
                else if (currentToken != LexicalAnalyzer.endsy)
                {
                    AddSyntaxError(123, "Ожидался ';' после оператора");
                    while (currentToken != LexicalAnalyzer.semicolon && 
                           currentToken != LexicalAnalyzer.endsy && 
                           currentToken != 0)
                    {
                        NextToken();
                    }
                    if (currentToken == LexicalAnalyzer.semicolon)
                        NextToken();
                }
            }

            if (currentToken != LexicalAnalyzer.endsy)
                AddSyntaxError(124, "Ожидался 'end'");
            else
                NextToken();
        }

        private void ParseStatement()
        {
            if (currentToken == LexicalAnalyzer.ident)
            {
                string identifier = GetCurrentIdentifier();
                NextToken();

                bool isIndexed = false;
                if (currentToken == LexicalAnalyzer.lbracket)
                {
                    isIndexed = true;
                    NextToken();
                    ParseExpression();
                    
                    if (currentToken == LexicalAnalyzer.rbracket)
                    {
                        NextToken();
                    }
                    else if (currentToken == LexicalAnalyzer.assign)
                    {
                        AddSyntaxError(125, "Отсутствует ']' в индексе массива");
                    }
                    else
                    {
                        AddSyntaxError(126, "Ожидался ']' в индексе массива");
                    }
                }

                if (currentToken == LexicalAnalyzer.equal)
                {
                    AddSyntaxError(133, "Использован '=' вместо ':=' в операторе присваивания");
                    NextToken();
                    ParseExpressionWithType();
                }
                else if (currentToken == LexicalAnalyzer.assign)
                {
                    NextToken();
                    string rightType = ParseExpressionWithType();
                    
                    if (isIndexed && declaredVariables.ContainsKey(identifier))
                    {
                        string varType = declaredVariables[identifier];
                        if (varType.StartsWith("array of integer") && rightType == "real")
                        {
                            AddSyntaxError(140, "Неверный тип данных для элемента массива");
                        }
                    }
                }
                else if (currentToken == LexicalAnalyzer.leftpar)
                {
                    ParseProcedureCall(identifier);
                }
                else if (currentToken == LexicalAnalyzer.intc || currentToken == LexicalAnalyzer.floatc)
                {
                    AddSyntaxError(132, "Отсутствует ':=' в операторе присваивания");
                    ParseExpression();
                }
            }
            else if (currentToken == LexicalAnalyzer.beginsy)
            {
                ParseCompoundStatement();
            }
        }

        private void ParseProcedureCall(string procedureName)
        {
            NextToken(); 
            
            List<string> argumentTypes = new List<string>();
            
            if (currentToken != LexicalAnalyzer.rightpar)
            {
                do
                {
                    string argType = ParseExpressionWithType();
                    argumentTypes.Add(argType);
                    
                    if (currentToken == LexicalAnalyzer.comma)
                    {
                        NextToken();
                    }
                    else
                    {
                        break;
                    }
                }
                while (currentToken != LexicalAnalyzer.rightpar && currentToken != 0);
            }
            
            if (currentToken != LexicalAnalyzer.rightpar)
                AddSyntaxError(128, "Ожидался ')' после аргументов");
            else
                NextToken();
            
            if (declaredProcedures.ContainsKey(procedureName))
            {
                ProcedureInfo procInfo = declaredProcedures[procedureName];
                if (procInfo.ParameterTypes.Count != argumentTypes.Count)
                {
                    AddSyntaxError(129, $"Неверное количество аргументов для процедуры '{procedureName}'");
                }
                else
                {
                    for (int i = 0; i < argumentTypes.Count; i++)
                    {
                        if (argumentTypes[i] != procInfo.ParameterTypes[i])
                        {
                            AddSyntaxError(130, $"Неверный тип аргумента для процедуры '{procedureName}'");
                        }
                    }
                }
            }
            else
            {
                AddSyntaxError(131, $"Процедура '{procedureName}' не объявлена");
            }
        }

        private void ParseExpression()
        {
            if (currentToken == LexicalAnalyzer.intc || currentToken == LexicalAnalyzer.floatc || 
                currentToken == LexicalAnalyzer.ident || currentToken == LexicalAnalyzer.charc)
            {
                NextToken();
            }
        }

        private string ParseExpressionWithType()
        {
            if (currentToken == LexicalAnalyzer.intc)
            {
                NextToken();
                return "integer";
            }
            else if (currentToken == LexicalAnalyzer.floatc)
            {
                NextToken();
                return "real";
            }
            else if (currentToken == LexicalAnalyzer.charc)
            {
                NextToken();
                return "char";
            }
            else if (currentToken == LexicalAnalyzer.ident)
            {
                string identifier = GetCurrentIdentifier();
                NextToken();
                
                if (identifier == "true" || identifier == "false")
                {
                    return "boolean";
                }
                
                if (declaredVariables.ContainsKey(identifier))
                {
                    return declaredVariables[identifier];
                }
                return "unknown";
            }
            return "unknown";
        }

        private string GetCurrentIdentifier()
        {
            return lexer.CurrentIdentifier ?? "unknown";
        }
    }
} 